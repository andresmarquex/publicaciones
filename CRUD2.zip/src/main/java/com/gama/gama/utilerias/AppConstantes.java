package com.gama.gama.utilerias;

public class AppConstantes {
    public static final String NUMERO_DE_PAGINA_POR_DEFECTO = "0";
    public static final String MEDIDA_DE_PAGINA_POR_DEFECTO = "10";
    public static final String ORDENAR_POR_DEFECTO = "id";
    public static final String ORDENAR_DIRECCION_POR_DEFECTO = "asc";
}

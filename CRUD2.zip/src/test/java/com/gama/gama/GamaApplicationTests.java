package com.gama.gama;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GamaApplicationTests {

	@Test
	void contextLoads() {
	}

}
